package com.example.navigation

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val nameTextView = findViewById<EditText>(R.id.nameTextView)
        val ageTextView = findViewById<EditText>(R.id.ageTextView)
        val phoneTextView = findViewById<EditText>(R.id.phoneTextView)
        val emailTextView = findViewById<EditText>(R.id.emailTextView)
        val nextButton = findViewById<Button>(R.id.nextButton)

        nextButton.setOnClickListener {
            val intent = Intent(this, SecondActivity::class.java)
            val name = nameTextView.text.toString()
            val email = emailTextView.text.toString()
            val age = ageTextView.text.toString()
            val phoneNumber = phoneTextView.text.toString()

            intent.putExtra("name", name)
            intent.putExtra("age", age)
            intent.putExtra("phone", phoneNumber)
            intent.putExtra("email", email)


            startActivity(intent)
        }
    }
}