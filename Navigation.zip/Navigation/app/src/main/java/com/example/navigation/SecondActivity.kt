package com.example.navigation

import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity


class SecondActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_second)

        val nameLabel = findViewById<TextView>(R.id.nameText)
        val ageLabel = findViewById<TextView>(R.id.ageText)
        val emailLabel = findViewById<TextView>(R.id.emailText)
        val phoneLabel = findViewById<TextView>(R.id.phoneText)


        val intent = intent

        val name = intent.getStringExtra("name")
        val age = intent.getStringExtra("age")
        val phone = intent.getStringExtra("phone")
        val email = intent.getStringExtra("email")

        nameLabel.text = name
        ageLabel.text = age
        phoneLabel.text = phone
        emailLabel.text = email



    }
}